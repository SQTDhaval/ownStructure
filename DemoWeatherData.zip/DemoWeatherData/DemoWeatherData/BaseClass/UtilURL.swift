//
//  UtilURL.swift
//  DemoWeatherData
//
//  Created by softqube on 05/11/19.
//  Copyright © 2019 softqube. All rights reserved.
//

import Foundation

var baseURL = "https://samples.openweathermap.org/data/2.5/forecast?lat=35&lon=139&appid=b6907d289e10d714a6e88b30761fae22#"


